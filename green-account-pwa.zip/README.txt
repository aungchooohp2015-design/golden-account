Green Account Demo — PWA
==========================
1. ဒီ folder ကို HTTPS website အဖြစ် host လုပ်ပါ။
2. iPhone Safari မှာ website ကိုဖွင့်ပါ။
3. Share -> Add to Home Screen ကိုနှိပ်ပါ။
4. App icon ကနေ တစ်ချက်နှိပ်ပြီး standalone ပုံစံနဲ့ ဖွင့်နိုင်ပါမယ်။
Android Chrome မှာလည်း Install App / Add to Home screen ပေါ်လာနိုင်ပါတယ်။

ဤ project သည် demo/UI အတွက်သာဖြစ်ပြီး ငွေလောင်းခြင်း၊ ငွေသွင်း/ငွေထုတ်၊ လောင်းကြေးတင်ခြင်း မပါဝင်ပါ။
